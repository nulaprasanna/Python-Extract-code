# Course Repo
- **Title:** Python Essential Training
- **Instructor:** Bill Weinman
- **Platform:** LinkedIn Learning
- **Note(s):**
