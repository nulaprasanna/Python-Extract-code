CREATE TABLE customer (
  ID STRING NOT NULL,
  Name STRING ,
  Address STRING ,
  City STRING,
  PostCode Number ,
  State STRING ,
  Company STRING,
  Contact STRING 
);