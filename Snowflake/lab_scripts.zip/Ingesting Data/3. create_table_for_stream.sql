CREATE DATABASE ingest_data;

CREATE TABLE transactions (
  Transactiion_Date DATE,
  Customer_ID string,
  Transaction_ID integer ,
  Amount integer
  );