CREATE DATABASE ingest_data;

CREATE TABLE customer (
  Customer_ID string,
  Customer_Name string ,
  Customer_Email string ,
  Customer_City string ,
  Customer_State string ,
  Customer_DOB DATE
  );